/*
 * RememberMeLogoutHandler.java
 *
 * Copyright (c) 2019 Rafael Corchuelo.
 *
 * In keeping with the traditional purpose of furthering education and research, it is
 * the policy of the copyright owner to permit non-commercial use and redistribution of
 * this software. It has been tested carefully, but it is not guaranteed for any particular
 * purposes. The copyright owner does not offer any warranties or representations, nor do
 * they accept any liabilities with respect to them.
 */

package acme.framework.utilities;

import java.util.Arrays;
import java.util.List;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.LogoutHandler;

import acme.framework.helpers.StringHelper;

public final class RememberMeLogoutHandler implements LogoutHandler {

	// Internal state ---------------------------------------------------------

	private final List<String> cookiesToClear;


	// Constructors -----------------------------------------------------------

	public RememberMeLogoutHandler(final String... cookiesToClear) {
		assert !StringHelper.someBlank(cookiesToClear);

		this.cookiesToClear = Arrays.asList(cookiesToClear);
	}

	@Override
	public void logout(final HttpServletRequest request, final HttpServletResponse response, final Authentication authentication) {
		assert request != null;
		assert response != null;
		assert authentication != null;

		Cookie cookie;
		String cookiePath;

		for (String cookieName : this.cookiesToClear) {
			cookiePath = request.getContextPath();

			cookie = new Cookie(cookieName, null);
			cookie.setPath(cookiePath);
			cookie.setMaxAge(0);
			response.addCookie(cookie);
		}
	}
}
